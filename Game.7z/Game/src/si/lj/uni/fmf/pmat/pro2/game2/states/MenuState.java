package si.lj.uni.fmf.pmat.pro2.game2.states;

import java.awt.Color;
import java.awt.Graphics;

import si.lj.uni.fmf.pmat.pro2.game2.Handler;
import si.lj.uni.fmf.pmat.pro2.game2.tools.Assets;
import si.lj.uni.fmf.pmat.pro2.game2.tools.ClickListener;
import si.lj.uni.fmf.pmat.pro2.game2.ui.UIImageButton;
import si.lj.uni.fmf.pmat.pro2.game2.ui.UIManager;

public class MenuState extends State {	
	private UIManager uiManager;
	
	public MenuState(Handler handler) {
		super(handler);
		
		this.stateName = "Menu state";
		uiManager = new UIManager(handler);
		handler.getMouseManager().setUIManager(uiManager);	//tko dobimo �e mouse events
		
		//naslednje nam dovoli da dodamo new game button
		uiManager.addObject(new UIImageButton(280, 500, 120, 70, Assets.playButton, new ClickListener() {
		
			@Override
			public void onClick() { // k kle kliknemo gremo na igro
				handler.getMouseManager().setUIManager(null); // toj zato d k si v igri d nemors kr kliknt na start button
				handler.getGame().startGame();
			}
			
		}));
	}

	@Override
	public void tick() {
		uiManager.tick();
	}

	@Override
	public void render(Graphics g) {
		g.draw3DRect(0, 0, 700, 700, false);
		g.setColor(new Color(102, 0, 153));
		g.fill3DRect(0, 0, 700, 700, false);
		g.drawImage(Assets.gameName, 60, 30, 600, 600, null);
			
		uiManager.render(g);
	}
	
	

}
