package si.lj.uni.fmf.pmat.pro2.game2.tools;

import java.awt.image.BufferedImage;

/**
 * kle je vsa muzka slike itd, nardimo posebi class zto d se zadeve naloudajo sam enx in ne d jih v zanki play loudamo vsako milisek al nvm kok ze
 * @author Tea
 *
 */

public class Assets {
	
	private static final int width = 32;
	private static final int height = 32;
	
	public static BufferedImage player;
	public static BufferedImage grass;
	public static BufferedImage food;
	public static BufferedImage stone;
	public static BufferedImage playerWarrior;
	public static BufferedImage glass;
	public static BufferedImage bush;
	
	public static BufferedImage[] killCucumber;
	public static BufferedImage[] playButton;
	
	
	public static BufferedImage question;
	public static BufferedImage back;
	
	public static BufferedImage gameOver;
	public static BufferedImage gameName;
	
	
	/**
	 * this init method is going to load in all our assets at once
	 */
	public static void init() {
		SpriteSheet sheet = new SpriteSheet(ImageLoader.loadImage("/textures/sheet_new.png"));
		
		killCucumber = new BufferedImage[3];
		
		killCucumber[0] = sheet.crop(width * 2, 0, width, height); // cucumber
		killCucumber[1] = sheet.crop(width, 0, width, height); // bomb
		killCucumber[2] = sheet.crop(width * 12, 0, width, height); // flame
		
		
		player = sheet.crop(0, 0, width, height); 
		food = sheet.crop(width * 3, 0, width, height);
		grass = sheet.crop(width * 4, 0, width, height);
		stone = sheet.crop(width * 5, 0, width, height);
		playerWarrior = sheet.crop(width * 6, 0, width, height);
		glass = sheet.crop(width * 7, 0, width, height);
		bush = sheet.crop(width * 8, 0, width, height);
		
		playButton = new BufferedImage[2];
		playButton[0] = sheet.crop(width * 15, 8, width, 7);
		playButton[1] = sheet.crop(width * 16, 8, width, 7);
		 
		question = sheet.crop(width * 10 + 5, 9, 20, 10);
		back = sheet.crop(width * 11 + 20, 8, 11, 9);
		
		gameOver = sheet.crop(width * 13, 0, width, height);
		gameName = sheet.crop(width * 14, 0, width, height);
		
	}
	
}
