package si.lj.uni.fmf.pmat.pro2.game2.tile;

import si.lj.uni.fmf.pmat.pro2.game2.tools.Assets;

public class RockTile extends Tile {

	public RockTile(int id) {
		super(Assets.stone, id);
	}
	
	// a rock tile is solid so we cannot walk on it
	@Override
	public boolean isSolid() {
		return true; // u are not allowed to walk on it
	}
}
