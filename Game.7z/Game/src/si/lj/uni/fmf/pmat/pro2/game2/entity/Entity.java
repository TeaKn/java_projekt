package si.lj.uni.fmf.pmat.pro2.game2.entity;

import java.awt.Graphics;
import java.awt.Rectangle;

import si.lj.uni.fmf.pmat.pro2.game2.Handler;

public abstract class Entity {
	
	//public static final int DEFAULT_HEALTH = 10; // initial setting of health
	public static final int DEFAULT_SCORE = 0;
	protected Handler handler;
	
	// position of entity on the screen
	protected float x; //basically like a private varibale but classes that extend this class will also have them
	protected float y; // they are float so taht we have a flow movement smooth
	
	// size of the entity
	protected int width;
	protected int height;
	
	//health
	protected int health;
	public boolean active = true; // k bo false bomo odstranil entity
	
	//score
	protected int score;
	
	//bounds
	protected Rectangle bounds;
	
	/**
	 * konstruktor
	 * @param handler
	 * @param x
	 * @param y
	 * @param height
	 * @param width
	 */
	public Entity(Handler handler, float x, float y, int height, int width) {
		this.handler = handler;
		this.x = x;
		this.y = y;
		this.height = height;
		this.width = width;
		score = DEFAULT_SCORE;
		
		bounds = new Rectangle(0, 0, width, height); // za zdj je rectangle iste velikosti kokr entity
	}
	
	public abstract void die(); // das sm abstraktno ker ho� d ma vsak entity svoj originalen die method
	
	public void hurt(int amt) {
		active = false;
		die();
	}
	
	public void gain(int amt) {
		score += amt;
	}
	
	public abstract void tick();
	
	public abstract void render(Graphics g);
	
	//helper methods
	
	public boolean checkEntityCollisions(float xOffset, float yOffset) {
		for(Entity e : handler.getWorld().getEntityManager().getEntities()) {
			if(e.equals(this))
				continue; // mi gremo po seznamu enitiejev in gledamo �e mamo collision ampak te�ava je d smo mi sami kot player tud not, zto se presko�mo
			if(e.getCollisionBounds(0f, 0f).intersects(getCollisionBounds(xOffset, yOffset)));
				return true;
		}
		return false;
	}
	
	/**
	 * Returns the area or the bounding rectangle that is around our entity.
	 * @param xOffset
	 * @param yOffset
	 * @return
	 */
	public Rectangle getCollisionBounds(float xOffset, float yOffset) {
		return new Rectangle((int) (x + bounds.x + xOffset), (int) (y + bounds.y + yOffset), bounds.width, bounds.height);
	}
	
	
	// setter in getter metode
	public float getX() {
		return x;
	}

	public void setX(float x) {
		this.x = x;
	}

	public float getY() {
		return y;
	}

	public void setY(float y) {
		this.y = y;
	}

	public int getWidth() {
		return width;
	}

	public void setWidth(int width) {
		this.width = width;
	}

	public int getHeight() {
		return height;
	}

	public void setHeight(int height) {
		this.height = height;
	}

	public boolean isActive() {
		return active;
	}

	public void setActive(boolean active) {
		this.active = active;
	}

	public int getScore() {
		return score;
	}

	public void setScore(int score) {
		this.score = score;
	}

	public void addScore(int score) {
		this.score += score;
	}
	
	
	
}
