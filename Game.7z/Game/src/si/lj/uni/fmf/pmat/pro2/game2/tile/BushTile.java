package si.lj.uni.fmf.pmat.pro2.game2.tile;

import si.lj.uni.fmf.pmat.pro2.game2.tools.Assets;

public class BushTile extends Tile {

	public BushTile(int id) {
		super(Assets.bush, id);
	}

}
