package si.lj.uni.fmf.pmat.pro2.game2.entity;

import si.lj.uni.fmf.pmat.pro2.game2.Handler;
import si.lj.uni.fmf.pmat.pro2.game2.tile.Tile;

public abstract class Creature extends Entity {
	
	public static final float DEFAULT_SPEED = 3.0f;
	public static final int DEFAULT_CREATURE_WIDTH = 64;
	public static final int DEFAULT_CREATURE_HEIGHT = 64; // kvadratne creaturje mamo
	
	protected float speed;
	// movement
	protected float xMove;
	protected float yMove;
	
	public Creature(Handler handler, float x, float y, int width, int height) { // loakcija ter velikost
		super(handler, x, y, width, height);
		speed = DEFAULT_SPEED;
		xMove = 0;
		yMove = 0;
	}
	
	/**
	 * Move method.
	 */
	public void move() {
		  moveX(); 
		  moveY();
	}
	
	// collision detection
	
	public void moveX() {
		if(xMove > 0) { // Moving right
			int tx = (int) (x + xMove + bounds.x + bounds.width) / Tile.TILEWIDTH; // where we are moving to - x
			if (!collisionWithTile(tx, (int) (y + bounds.y) / Tile.TILEHEIGHT) && (!collisionWithTile(tx, (int) (y + bounds.y) / Tile.TILEWIDTH))) {
				x += xMove;
			}
		}else if(xMove < 0) { // Moving left
			int tx = (int) (x + xMove + bounds.x) / Tile.TILEWIDTH; // where we are moving to - x
			if (!collisionWithTile(tx, (int) (y + bounds.y) / Tile.TILEHEIGHT) && (!collisionWithTile(tx, (int) (y + bounds.y) / Tile.TILEWIDTH))) {
				x += xMove;
			}
		}
	}
	
	public void moveY() {
		if (yMove < 0) { // moving up
			int ty = (int) (y + yMove + bounds.y) / Tile.TILEHEIGHT;
			if(!collisionWithTile((int) (x + bounds.x) / Tile.TILEWIDTH, ty) && (!collisionWithTile((int) (x + bounds.x) / Tile.TILEWIDTH, ty))){
				y += yMove;
			}
		}else if(yMove > 0) { // moving down
 		    int ty = (int) (y + yMove + bounds.y + bounds.height) / Tile.TILEHEIGHT;
			if(!collisionWithTile((int) (x + bounds.x) / Tile.TILEWIDTH, ty) && (!collisionWithTile((int) (x + bounds.x) / Tile.TILEWIDTH, ty))){
				y += yMove;
			}
		}
	}
	
	/**
	 * It takes a (x,y) tile coordinate. Returns true if the tile is solid if not false.
	 * @param x
	 * @param y
	 * @return
	 */
	protected boolean collisionWithTile(int x, int y) {
		return handler.getWorld().getTile(x, y).isSolid();
	}
	
	// GETTER AND SETTERS

	// getter in setter metode za movement
	public float getxMove() {
		return xMove;
	}


	public void setxMove(float xMove) {
		this.xMove = xMove;
	}


	public float getyMove() {
		return yMove;
	}


	public void setyMove(float yMove) {
		this.yMove = yMove;
	}


	// getter in setter metode sam za speed in health ker so protected 
	public int getHealth() {
		return health;
	}

	public void setHealth(int health) {
		this.health = health;
	}

	public float getSpeed() {
		return speed;
	}

	public void setSpeed(float speed) {
		this.speed = speed;
	}

}
