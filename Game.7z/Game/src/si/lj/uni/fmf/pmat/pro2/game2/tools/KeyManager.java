package si.lj.uni.fmf.pmat.pro2.game2.tools;

import java.awt.event.KeyEvent;
import java.awt.event.KeyListener;

public class KeyManager implements KeyListener {
	
	private boolean[] keys;
	
	//kam hodimo
	public boolean up;
	public boolean down;
	public boolean left;
	public boolean right;
	
	// kam streljamo ali kam gledamo ni povezano z hojo, attack buttons
	public boolean aSpace;
	
	
	/**
	 * konstuktor
	 */
	public KeyManager() {
		keys = new boolean[256];
	}
	
	public void tick() {
		up = keys[KeyEvent.VK_W]; // W je znak za up
		down = keys[KeyEvent.VK_S];
		left = keys[KeyEvent.VK_A];
		right = keys[KeyEvent.VK_D]; // kle smo se tko odlocl za te �rke lah tud pu��ice
	
		// attack only with space key
		aSpace = keys[KeyEvent.VK_SPACE];
		 
	}

	@Override
	public void keyPressed(KeyEvent e) { // e kot event
		keys[e.getKeyCode()] = true; // the key is being pressed
		//System.out.println("Pressed!");
	}

	@Override
	public void keyReleased(KeyEvent e) {
		keys[e.getKeyCode()] = false; // the key is no longer being pressed
		
	}

	@Override
	public void keyTyped(KeyEvent e) {
		
		
	}
	

}
