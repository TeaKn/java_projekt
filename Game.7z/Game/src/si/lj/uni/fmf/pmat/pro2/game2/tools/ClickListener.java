package si.lj.uni.fmf.pmat.pro2.game2.tools;

/**
 * an interface is a template for a class. don't contain methods only the structure of the class.
 * to mamo zto d nimamo posebi classe za start button, quit itd ampak je vse pod eno streho
 *
 *
 */
public interface ClickListener {
	
	public void onClick(); // must have this method

}
