package si.lj.uni.fmf.pmat.pro2.game2.tools;

import java.awt.image.BufferedImage;

public class SpriteSheet {

	private BufferedImage sheet;
	
	public SpriteSheet(BufferedImage sheet) {
		 this.sheet = sheet;
	}
	
	/**
	 * metoda ki croppa sliko
	 * @return
	 */
	public BufferedImage crop(int x, int y, int width, int height) {
		return sheet.getSubimage(x, y, width, height);
	}
}
