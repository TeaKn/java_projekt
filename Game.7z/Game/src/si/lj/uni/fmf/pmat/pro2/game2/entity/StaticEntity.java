package si.lj.uni.fmf.pmat.pro2.game2.entity;

import si.lj.uni.fmf.pmat.pro2.game2.Handler;

/**
 * an entity that doesn't move around, like a tree or a rock.
 *
 */
public abstract class StaticEntity extends Entity{
	
	public StaticEntity(Handler handler, float x, float y, int width, int height) {
		super(handler, x, y, width, height);
	}
	
	

}
