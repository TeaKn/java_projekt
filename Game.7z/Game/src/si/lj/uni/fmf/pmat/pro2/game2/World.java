package si.lj.uni.fmf.pmat.pro2.game2;

import java.awt.Graphics;
import java.util.Random;

import si.lj.uni.fmf.pmat.pro2.game2.entity.Bomb;
import si.lj.uni.fmf.pmat.pro2.game2.entity.Cucumber;
import si.lj.uni.fmf.pmat.pro2.game2.entity.EntityManager;
import si.lj.uni.fmf.pmat.pro2.game2.entity.Food;
import si.lj.uni.fmf.pmat.pro2.game2.entity.Glass;
import si.lj.uni.fmf.pmat.pro2.game2.entity.Player;
import si.lj.uni.fmf.pmat.pro2.game2.tile.Tile;
import si.lj.uni.fmf.pmat.pro2.game2.tools.Utils;

public class World {
	
	private Handler handler;
	private int spawnX;
	private int spawnY; //zacetna pozicija
	private int height;
	private int width;
	private int[][] tiles; // is going to hold id of tiles zto int
	//Entities
	private EntityManager entityManager;
	
	
	// load up a world from a file
	public World(Handler handler, String path) {
		this.handler = handler;
		entityManager = new EntityManager(handler, new Player(handler, 200, 100)); // to se more zgodit predn naloudamo svet
		
		loadWorld(path);
		
		// load entities
		int tileWidth = 64;
		int tileHeight = 64;
		int maxBombAmount = 10;
		for ( int i = 0; i < tiles.length - 1; i++) {
			for (int j = 0; j < tiles[i].length - 1; j++) {
				if (tiles[i][j] == 0 ) {
					Random random = new Random();
					int rand = random.nextInt(45); // damo ve�jo cifro zato d niso na vsakmu zelemnu tajlu
					if(rand == 0) {
						if(maxBombAmount > 0) {
							entityManager.addEntity(new Bomb(handler, tileWidth * i, tileHeight * j));	
							maxBombAmount--;
						}
					} // tako bodo bombe razporejene po celi plo��i					
					else if (rand == 1 || rand == 2 || rand == 3)
						entityManager.addEntity(new Food(handler, tileWidth * i, tileHeight * j));
					else if (rand == 4 || rand == 5 || rand == 6)
						entityManager.addEntity(new Glass(handler, tileWidth * i, tileHeight * j)); // tko doda� entity, �e jih ho� ve� sam loop
					else if(rand == 7 || rand == 8 || rand == 9)
						entityManager.addEntity(new Cucumber(handler, tileWidth * i, tileHeight * j));
					 
				}
			}
			
		}
		// so that the spawn numbers in our world file actually work
		entityManager.getPlayer().setX(spawnX);
		entityManager.getPlayer().setX(spawnY);	
	}
	
	public void tick() {
		entityManager.tick();
	}
	
	public void render (Graphics g) {
		
		// a limit to the render method, we only want to draw the tiles we can actually see
		int xStart = (int) Math.max(0, handler.getGameCamera().getxOffset() / Tile.TILEWIDTH); // nocmo met neg stevil, �e damo tm �e + 1 na desni, bomo vidl kako izginja world na levi strani, kalkulacija bo samo risala tiste tajle k jih vidimo
		int xEnd = (int) Math.min(width, (handler.getGameCamera().getxOffset() + handler.getWidth()) / Tile.TILEWIDTH + 1);
		int yStart = (int) Math.max(0, handler.getGameCamera().getyOffset() / Tile.TILEHEIGHT);
		int yEnd = (int) Math.min(height, (handler.getGameCamera().getyOffset() + handler.getHeight()) / Tile.TILEHEIGHT + 1);
		
		for (int y = yStart; y < yEnd; y++) {
			for (int x = xStart; x < xEnd; x++) {
				getTile(x,y).render(g, (int) (x * Tile.TILEWIDTH - handler.getGameCamera().getxOffset()), (int) (y * Tile.TILEHEIGHT - handler.getGameCamera().getyOffset())); // mor� pomno�it kr tko converta� v pixle, kr �e das sam 5x5 bo to ful mal placa
			}
		}
		//Entities
		entityManager.render(g);
	}
	
	/**
	 * we are taking a tiles array and we are indexing
	 * @param x
	 * @param y
	 * @return
	 */
	public Tile getTile(int x, int y) {
		if(x < 0 || y < 0 || x >= width || y >= height) // this is just to prevent any errors, tud �e je nekak prsu izven igre mu recemo kao d je na travi
			return Tile.grassTile;
		Tile t = Tile.tiles[tiles[x][y]];
		if(t == null)
			return Tile.grassTile; // returnam default tile k sm rekla d bo grass tile
		return t;
	}
	
	
	private void loadWorld(String path) {
		String file = Utils.loadFileAsString(path);
		String[] tokens = file.split("\\s+");
		width = Utils.parseInt(tokens[0]);
		height = Utils.parseInt(tokens[1]);
		spawnX = Utils.parseInt(tokens[2]);
		spawnY = Utils.parseInt(tokens[3]);
		
		tiles = new int[width][height];
		for (int y = 0; y < height; y++) {
			for (int x = 0; x < width; x++) {
				tiles[x][y] = Utils.parseInt(tokens[(x + y * width) + 4]);
			}
		}
	}
	
	
	// GETTERS AND SETTERS
	
	
	public int getWidth() {
		return width;
	}
	
	public int getHeight() {
		return height;
	}

	public int getSpawnX() {
		return spawnX;
	}

	public void setSpawnX(int spawnX) {
		this.spawnX = spawnX;
	}

	public int getSpawnY() {
		return spawnY;
	}

	public void setSpawnY(int spawnY) {
		this.spawnY = spawnY;
	}

	public EntityManager getEntityManager() {
		return entityManager;
	}
	
	
	
	
}
