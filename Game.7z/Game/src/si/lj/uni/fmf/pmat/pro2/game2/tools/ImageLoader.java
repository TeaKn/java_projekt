package si.lj.uni.fmf.pmat.pro2.game2.tools;

import java.awt.image.BufferedImage;
import java.io.IOException;

import javax.imageio.ImageIO;

public class ImageLoader {

	public static BufferedImage loadImage(String path) {
		try {
			return ImageIO.read(ImageLoader.class.getResource(path));
		} catch (IOException e) {
			e.printStackTrace();
			System.exit(1); // if we don't load image to game we don't want to run the game
		}
		return null;
	}
	
}
