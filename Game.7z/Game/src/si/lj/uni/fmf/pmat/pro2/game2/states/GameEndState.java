package si.lj.uni.fmf.pmat.pro2.game2.states;

import java.awt.Color;
import java.awt.Font;
import java.awt.Graphics;

import si.lj.uni.fmf.pmat.pro2.game2.Handler;
import si.lj.uni.fmf.pmat.pro2.game2.tools.Assets;

public class GameEndState extends State {

	public GameEndState(Handler handler) {
		super(handler);
		this.stateName = "Game end state";
	}

	@Override
	public void tick() {
		
	}

	@Override
	public void render(Graphics g) {
		g.draw3DRect(0, 0, 700, 700, false);
		g.setColor(new Color(102, 0, 153));
		g.fill3DRect(0, 0, 700, 700, false);
		
		g.drawImage(Assets.gameOver, 50, 30, 650, 650, null);
		g.setColor(new Color(204, 204, 204));
		g.setFont(new Font("TimesRoman", Font.BOLD, 20));
		g.drawString("SCORE: " + handler.getWorld().getEntityManager().getPlayer().getScore(), 300, 600);
		
	}

}
