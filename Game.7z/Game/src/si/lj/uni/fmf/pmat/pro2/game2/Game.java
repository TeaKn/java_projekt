package si.lj.uni.fmf.pmat.pro2.game2;

import java.awt.Color;
import java.awt.Graphics;
import java.awt.image.BufferStrategy;
import java.awt.image.BufferedImage;

import si.lj.uni.fmf.pmat.pro2.game2.states.GameEndState;
import si.lj.uni.fmf.pmat.pro2.game2.states.GameState; 
import si.lj.uni.fmf.pmat.pro2.game2.states.MenuState;
import si.lj.uni.fmf.pmat.pro2.game2.states.State;
import si.lj.uni.fmf.pmat.pro2.game2.tools.Assets;
import si.lj.uni.fmf.pmat.pro2.game2.tools.KeyManager;
import si.lj.uni.fmf.pmat.pro2.game2.tools.MouseManager;

/**
 * This is the main class, here is everything that the game does.
 * 
 *
 */
public class Game implements Runnable{
	
	private Display display;

	//timer
	private boolean gameStarted;
	private int endGameAt = 30; //seconds
	
	private int width;
	private int height;
	public String title;
	
	private boolean running = false;
	
	// what is a thread? big program that starts and mini program which runs separately from big program
	private Thread thread;
	
	private BufferStrategy bs;
	private Graphics g;
	
	//States 
	public State gameState;
	public State menuState;
	public State gameEndState;
	
	
	//Input
	private KeyManager keyManager;
	private MouseManager mouseManager;
	
	//Camera
	private GameCamera gameCamera;
	
	//Handler
	private Handler handler;

	
	public Game(String title, int width, int height) {
		this.width = width;
		this.height = height;
		this.title = title;
		keyManager = new KeyManager();
		mouseManager = new MouseManager();
	}
	
	/**
	 * vakic ko bo run biu poklican bo poklical init medoto ki inicializira grafi�ne predele igre
	 */
	private void init() {
		display = new Display(title, width, height);
		display.getFrame().addKeyListener(keyManager); // we get the jframe and add a key listener which allows us to acces the keyboard
		display.getFrame().addMouseListener(mouseManager);		
		display.getFrame().addMouseMotionListener(mouseManager);	
		display.getCanvas().addKeyListener(keyManager); 
		display.getCanvas().addMouseListener(mouseManager);	
		display.getCanvas().addMouseMotionListener(mouseManager);		
		Assets.init();
		
		handler = new Handler(this);
		handler.setTimer(this.endGameAt);
		gameCamera =  new GameCamera(handler, 0, 0); //first we wanna draw it at the normal position cuz nothing is shifted
		
		gameState = new GameState(handler); // we can do this beacuse our gamestate class extends our state class
		menuState = new MenuState(handler); // we have to initialize the states
		gameEndState = new GameEndState(handler);
		State.setState(menuState);
	}
	
	
	/**
	 * this updates the game
	 */
	private void tick() {
		keyManager.tick(); //very important
		if(State.getState() != null)
			State.getState().tick();
	}
	
	/**
	 * this draws the game 
	 */
	private void render() {
		bs = display.getCanvas().getBufferStrategy(); //buffer strategy pove kompu kako narisat neki na screen, uporabmo to da igra ne flickera
		if(bs == null) {
			display.getCanvas().createBufferStrategy(3); // torj �e �e nimamo ga ustavri in ma 3 
			return;
		}
		
		// zdj lah risemo
		g = bs.getDrawGraphics(); // create the paintbrush
		// Clear Screen
		g.clearRect(0, 0, width, height);
		// Draw Here
		
		if(State.getState() != null)
			State.getState().render(g);
		
		
		// End drawing
		bs.show();
		g.dispose();
	}
	
	/**
	 * this is where the majority of the game code goes
	 */
	public void run() {
		
		init();
		
		//Game Timer
		int fps = 60; //frames per second, or update/tick per second
		double timePerTick = 1000000000 / fps; // merimo �as v nanosekundah ker je bolj natan�no, max amount of time that we have to execute the update and render method
		double delta = 0;
		long now;
		long lastTime = System.nanoTime(); // returns the current amount time in nanoseconds that our computer is running at
		long timer = 0;
		int ticks = 0;
		
		
		while(running) { // spr runnign smo nardil kr d bi blo sam true ne bi bla uredu zanka
			now = System.nanoTime();
			delta += (now - lastTime) / timePerTick;
			timer += now - lastTime; //the amount of nanoseconds that has passed since we last called this method
			lastTime = now;
			
			if (delta >= 1) {
				tick(); // update the game
				render();
				ticks++;
				delta--; // we ticked and rendered then we substract one
			}
			
			if(timer >= 1000000000) {
				// Gameplay started
				if(gameStarted) {
					handler.decSecond();;
					
					if(handler.getTimer() <= 0) {
						gameOver();
					}
										
				}
				
				//System.out.println("Game time: " + handler.getTimer() +"s");
				ticks = 0;
				timer = 0;
			}
		}
		
		stop(); //just in case it hasn't been stopped by the loop
		
	}
	
	public void gameOver() {
		gameStarted = false;
		//System.out.println("gameover");
		State.setState(gameEndState);		
	}
	
	public void startGame() {
		gameStarted = true;
		endGameAt = 30; //seconds
		State.setState(gameState);
	}
	
	//getters
	
	public MouseManager getMouseManager() {
		return mouseManager;
	}
	
	public KeyManager getKeyManager() {
		return keyManager;
	}
	
	public GameCamera getGameCamera() {
		return gameCamera;
	}
	
	public int getWidth() {
		return width;
	}
	
	public int getHeight() {
		return height;
	}
	
	//
	
	public synchronized void start() {
		if(running) // �e igra �e te�e no�mo runnat une kode spodi
			return;
		running = true;
		thread = new Thread(this); // v oklepaje da� tp kar � runnat, torj ta game class
		thread.start(); // it starts the thread and calls the run method
	}

	public synchronized void stop() {
		if(!running) // no�mo igre uga�at �e je �e ugasnjena
			return;
		running = false;
		try {
			thread.join(); // da� to in pol ti te�i d more bit v try catch
		} catch (InterruptedException e) {
			e.printStackTrace();
		}
		
	}
}
