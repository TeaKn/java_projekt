package si.lj.uni.fmf.pmat.pro2.game2.entity;

import java.awt.Color;
import java.awt.Graphics;
import java.awt.Rectangle;

import si.lj.uni.fmf.pmat.pro2.game2.Handler;
import si.lj.uni.fmf.pmat.pro2.game2.tools.Assets;

public class Player extends Creature { 

	public Player(Handler handler, float x, float y) { // pozicija
		super(handler, x, y, Creature.DEFAULT_CREATURE_WIDTH, Creature.DEFAULT_CREATURE_HEIGHT);
	
		bounds.x = 20;
		bounds.y = 30;
		bounds.width = 20;
		bounds.height = 10;
	}

	@Override
	public void tick() {
		//Movement
		getInput();
		move();
		handler.getGameCamera().centerOnEntity(this); // pomen d we want to center this player. pomen d bo player v sredi��u nekak
		//Attack
		checkAttacks();
	}
	
	/**
	 * torj ko bo� attackal dol bomo nardil za�asen rectangle in �e bo entity not v rectanglu potem mu bomo zbijal health
	 */
	private void checkAttacks() {
		Rectangle cb = getCollisionBounds(0,0); // coordinates of the collision box of our player
		Rectangle ar = new Rectangle(); // attack rectangle
		int arSize = 40;
		ar.width = arSize;
		ar.height = arSize;
		
		if(handler.getKeyManager().aSpace) {
			ar.x = cb.x - 10;
			ar.y = cb.y - 10;
		}else { // none of these are being pressed the player isn't attactking at all 
			return; }
		
		
		//checking for the attacks
		
		for (Entity e : handler.getWorld().getEntityManager().getEntities()) {
			if(e.equals(this)) 
				continue; 
			if(e.getCollisionBounds(0, 0).intersects(ar)) {
				e.hurt(1); return; // we can hurt only one entity at a time
			}
		} 
		 
		
		// checking for gaining score
		for (Entity e : handler.getWorld().getEntityManager().getEntities()) {
			//System.out.println(e);
			if(e.equals(this))
				continue;
			if(e.getCollisionBounds(0, 0).intersects(ar)) {
				e.gain(1);
				return; 
			}
		}
		
	}
	
	@Override
	public void die() {
		System.out.println("You lose.");
	}
	
	/**
	 * input method, kle bo zdj porihatno kar je blo prj v metodu tick()
	 */
	private void getInput() {
		xMove = 0;
		yMove = 0;
		
		if(handler.getKeyManager().up)
			yMove = -speed;
		if(handler.getKeyManager().down)
			yMove = speed;
		if(handler.getKeyManager().left)
			xMove = -speed;
		if(handler.getKeyManager().right)
			xMove = speed;
		
	}

	@Override
	public void render(Graphics g) {
		g.drawImage(Assets.player, (int) (x - handler.getGameCamera().getxOffset()), (int) (y - handler.getGameCamera().getyOffset()), width, height, null); // casting convertal smo iz double v int, tuki tud nastavs velikost z width and height
	
		g.setColor(Color.white);
		g.drawString("" + handler.getTimer(), (int) (x + bounds.x - handler.getGameCamera().getxOffset()- 10), (int) (y + bounds.y - handler.getGameCamera().getyOffset() - 35));
		g.drawString("Score: " + this.getScore(), (int) (x + bounds.x - handler.getGameCamera().getxOffset() - 10 ), (int) (y + bounds.y - handler.getGameCamera().getyOffset() - 20));
		
		//g.setColor(Color.red);
		//g.fillRect((int) (x + bounds.x - handler.getGameCamera().getxOffset()), (int) (y + bounds.y - handler.getGameCamera().getyOffset()), bounds.width, bounds.height);		
		
	}

	
}
