package si.lj.uni.fmf.pmat.pro2.game2.states;

import java.awt.Graphics;

import si.lj.uni.fmf.pmat.pro2.game2.Handler;

/**
 * an abstract class is basically a bunch of variables and methods that can be used to create other classes
 * so here are the things that every single state must have (states: main menu, settings, game)
 * every single state has a tick and a render method
 * 
 *
 */
public abstract class State {
	
	//Game state manager
	private static State currentState = null;
	protected String stateName;
	
	public static void setState(State state) {
		currentState = state;
		System.out.println(state.getStateName());
	}
	
	public static State getState() {
		return currentState;
	}
	
	// CLASS
	protected Handler handler;
	
	public State(Handler handler) {
		this.handler = handler;
	}
	
	public abstract void tick();
	public abstract void render(Graphics g);
	
	public String getStateName() {
		return stateName;		
	}

}
