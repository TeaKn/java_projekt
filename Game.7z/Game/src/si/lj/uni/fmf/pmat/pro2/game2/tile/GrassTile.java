package si.lj.uni.fmf.pmat.pro2.game2.tile;

import si.lj.uni.fmf.pmat.pro2.game2.tools.Assets;

public class GrassTile extends Tile {
	
	public GrassTile(int id) {
		super(Assets.grass, id);
	}
}
