package si.lj.uni.fmf.pmat.pro2.game2.entity;

import java.awt.Color;
import java.awt.Graphics;

import si.lj.uni.fmf.pmat.pro2.game2.Handler;
import si.lj.uni.fmf.pmat.pro2.game2.tile.Tile;
import si.lj.uni.fmf.pmat.pro2.game2.tools.Assets;

public class Food extends StaticEntity {
	private int myScore = 20;

	public Food(Handler handler, float x, float y) {
		super(handler, x, y, Tile.TILEWIDTH, Tile.TILEHEIGHT * 2);
	
		//bounding box
		bounds.x = 10;
		bounds.y = 10;
		bounds.width = 20;
		bounds.height = 20;
	}
	
	@Override
	public void die() {
		//setScore
		handler.getWorld().getEntityManager().getPlayer().addScore(this.myScore); 		
	}

	@Override
	public void tick() {
		
	}


	@Override
	public void render(Graphics g) {
		g.drawImage(Assets.food, (int) (x - handler.getGameCamera().getxOffset()), (int) (y - handler.getGameCamera().getyOffset()), null);
		
		//g.setColor(Color.red);
		//g.fillRect((int) (x - handler.getGameCamera().getxOffset()), (int) (y - handler.getGameCamera().getyOffset()), bounds.width, bounds.height);
	
	}
}
