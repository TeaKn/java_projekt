package si.lj.uni.fmf.pmat.pro2.game2;

import java.awt.BorderLayout;
import java.awt.Canvas;
import java.awt.Dimension;

import javax.swing.JFrame;
import javax.swing.JPanel;

/**
 * Window 
 *
 *
 */
public class Display {
	
	private JFrame frame; 
	private Canvas canvas; // put images into the game
	
	
	// we draw all the grapihcs in the canvas and then we add it to the frame so we are able to see it
	
	private String title;
	private int width;
	private int height;
	
	/**
	 * konstuktor
	 * @param title
	 * @param width
	 * @param height
	 */
	public Display(String title, int width, int height) {
		this.title = title;
		this.width = width;
		this.height = height;
		
		createDisplay();
	}
	/**
	 * tukaj inicializiram JFrame inicializiramo canvas
	 * to damo sm dol in ne v konstruktor zard tega d ni gu�ve 
	 */
	private void createDisplay() {
		frame = new JFrame(title);
		frame.setSize(width, height);
		frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE); // toj zato d k da� kri�ec se porgram res zapre
		frame.setResizable(false); // i don't wanna resize
		frame.setLocationRelativeTo(null); // okno se bo odprlo na sredini ekrana ne v levemk kotu
		frame.setVisible(true);
		
		canvas = new Canvas();
		canvas.setPreferredSize(new Dimension(width, height));
		canvas.setMaximumSize(new Dimension(width, height));
		canvas.setMinimumSize(new Dimension(width, height));
		// this will make sure that the game is ALWAYS that size
		canvas.setFocusable(false); // ker nm drga� ne izpise neke reci
		
		
		frame.add(canvas); //dodamo canvas v frame
		frame.pack();
	}
	
	public Canvas getCanvas() {
		return canvas;
	}
	
	/**
	 * we do that beacuse we need to access the frame outside the display class
	 * @return frame
	 */
	public JFrame getFrame() {
		return frame;
	}
}
