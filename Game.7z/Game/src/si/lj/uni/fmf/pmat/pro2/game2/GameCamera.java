package si.lj.uni.fmf.pmat.pro2.game2;

import si.lj.uni.fmf.pmat.pro2.game2.entity.Entity;
import si.lj.uni.fmf.pmat.pro2.game2.tile.Tile;

/**
 * ma� world sam vid� lah sam en del worlda torj kle se premikamo po worldu na nek na�in 
 * 
 *
 */
public class GameCamera {
	
	private Handler handler;
	
	//how far off do we draw something from it's original position
	private float xOffset;
	private float yOffset;
	
	public GameCamera(Handler handler, float xOffset, float yOffset) {
		this.handler = handler;
		this.xOffset = xOffset;
		this.yOffset = yOffset;
	}
	
	/**
	 * it checks if the camera sees any blank space
	 */
	public void checkBlankSpace() {
		if(xOffset < 0) { // toj za levo
			xOffset = 0;
		}else if(xOffset > handler.getWorld().getWidth() * Tile.TILEWIDTH - handler.getWidth()) {
			xOffset = handler.getWorld().getWidth() * Tile.TILEWIDTH - handler.getWidth(); // to je za desno
		}
		if (yOffset < 0) { // toj za zgori
			yOffset = 0;
		}else if(yOffset > handler.getWorld().getHeight() * Tile.TILEHEIGHT - handler.getHeight()) { // toj za spodaj
			yOffset = handler.getWorld().getHeight() * Tile.TILEHEIGHT - handler.getHeight();
		}
	}
	
	/**
	 * what entity to center the camera on.
	 */
	public void centerOnEntity(Entity e) {
		xOffset = e.getX() - handler.getWidth() / 2 + e.getWidth() / 2;// dividing by 2 d je na sredini
		yOffset = e.getY() - handler.getHeight() / 2 + e.getHeight() / 2;
		checkBlankSpace();
	}
	
	/**
	 * camera move
	 * @param xAmt
	 * @param yAmt
	 */
	public void move(float xAmt, float yAmt) {
		xOffset += xAmt;
		yOffset += yAmt;
		checkBlankSpace();
	}
	
	//GETTER SETTER
	public float getxOffset() {
		return xOffset;
	}

	public void setxOffset(float xOffset) {
		this.xOffset = xOffset;
	}

	public float getyOffset() {
		return yOffset;
	}

	public void setyOffset(float yOffset) {
		this.yOffset = yOffset;
	}

	
}
