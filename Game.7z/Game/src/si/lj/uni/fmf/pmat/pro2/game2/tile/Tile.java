package si.lj.uni.fmf.pmat.pro2.game2.tile;

import java.awt.Graphics;
import java.awt.image.BufferedImage;

/**
 * kokr class entity, kle bodo vse lasnotsti tajlov
 * @author Tea
 *
 */
public class Tile {
	
	// STATIC STUFF
	public static Tile[] tiles = new Tile[256];
	public static Tile grassTile = new GrassTile(0); //id number of 0 is going to refer to a grass tile
	public static Tile rockTile = new RockTile(2);
	public static Tile bushTile = new BushTile(1);
	
	// CLASS STUFF
	public static final int TILEWIDTH = 64;
	public static final int TILEHEIGHT = 64; 
	
	protected BufferedImage texture;
	protected final int id; // id of the tile
	
	public Tile(BufferedImage texture, int id) {
		this.texture = texture;
		this.id = id;
		
		tiles[id] = this; // it is going to set the tile array at the proper index
	}
	
	public void tick() {
		
	}
	
	public void render(Graphics g, int x, int y) {
		g.drawImage(texture, x, y, TILEWIDTH, TILEHEIGHT, null);
	}
	
	//is a tile walkable or not
	public boolean isSolid() {
		return false; // u are allowed to walk on it
	}
	
	public int getId() {
		return id;
	}

}
