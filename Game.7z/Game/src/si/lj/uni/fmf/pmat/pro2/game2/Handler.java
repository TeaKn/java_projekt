package si.lj.uni.fmf.pmat.pro2.game2;

import si.lj.uni.fmf.pmat.pro2.game2.tools.KeyManager;
import si.lj.uni.fmf.pmat.pro2.game2.tools.MouseManager;

/**
 * notr ma in game in world, zto je tok kul, kr pol k bomo delal colision v creature bomo rabl accesat oboje
 * 
 *
 */
public class Handler {
	
	private Game game;
	private World world;
	
	//timer
	private int timer;
	
	
	public Handler(Game game) {
		this.game = game;
	}
	
	
	/**
	 * decrease 1 second to game timer
	 */
	public void decSecond() {
		this.timer -= 1;
	}
	
	//getters 
	
	public int getWidth() {
		return game.getWidth();
	}
	
	public int getHeight() {
		return game.getHeight();
	}
	
	public GameCamera getGameCamera() {
		return game.getGameCamera();
	}
	
	public MouseManager getMouseManager() {
		return game.getMouseManager();
	}
	
	public KeyManager getKeyManager() {
		return game.getKeyManager();
	}

	public Game getGame() {
		return game;
	}

	public void setGame(Game game) {
		this.game = game;
	}

	public World getWorld() {
		return world;
	}

	public void setWorld(World world) {
		this.world = world;
	}

	public int getTimer() {
		return this.timer;
	}

	public void setTimer(int timer) {
		this.timer = timer;
	}

	
	
}
