package si.lj.uni.fmf.pmat.pro2.game2;


/**
 * Tukaj se izvaja igra. not mamo main method.
 *
 *
 */
public class Launcher {
	/**
	 * creatam display
	 * 
	 */
	public static void main(String[] args) {
		Game game = new Game("Purple Cat", 700, 700);
		game.start();
	}

}
